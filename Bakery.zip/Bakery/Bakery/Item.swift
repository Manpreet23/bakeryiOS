//
//  Item.swift
//  Bakery
//
//  Created by Manpreet on 2020-11-23.
//

import Foundation
class Item
{
    var name : String
    var image : String
    var price : Double
    var ingredient : String
    init(name : String , image : String,price : Double,ingredient : String)
    {
        self.name = name
        self.image = image
        self.price = price
        self.ingredient = ingredient
    }
}
