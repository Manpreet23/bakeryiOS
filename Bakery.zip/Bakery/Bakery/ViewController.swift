//
//  ViewController.swift
//  Bakery
//
//  Created by Manpreet on 2020-11-20.
//

import UIKit

class ViewController: UIViewController {

   

    @IBOutlet weak var favitem: UITextField!
    @IBOutlet weak var alert: UILabel!
    @IBOutlet weak var phone: UITextField!
    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var city: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func submit(_ sender: Any) {
        
        if name.text == ""
        {
            alert.text = "Enter name"
        }
       else if city.text == ""
        {
            alert.text = "Enter city"
        }
       else if phone.text == ""
        {
            alert.text = "Enter phone"
        }
        
       else if favitem.text == ""
        {
            alert.text = "Enter favourite item"
        }
       else{
        performSegue(withIdentifier: "home", sender: self)
       }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let dash = segue.destination as? DashboardViewController
        dash?.welcomeName = name.text!
    }
}

