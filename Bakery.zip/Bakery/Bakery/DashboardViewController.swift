//
//  DashboardViewController.swift
//  Bakery
//
//  Created by Manpreet on 2020-11-23.
//

import UIKit

class DashboardViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    var itemList = [Item]()
    var image = ""
    var welcomeName = ""
    @IBOutlet weak var welcome: UITextField!
    var name = ""
    var price = 0.0
    var ingredient = ""
    
    @IBOutlet weak var itemView: UITableView!
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        itemList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let item = itemList[indexPath.row]
        let cell = itemView.dequeueReusableCell(withIdentifier: "itemcell") as? ItemViewCell
        cell?.setItem(item : item)
        return cell!
    }
    
   func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
       name = itemList[indexPath.row].name
       image = itemList[indexPath.row].image
      price = Double(itemList[indexPath.row].price)
  ingredient =  itemList[indexPath.row].ingredient
        performSegue(withIdentifier: "detail", sender: self)
    
    }
  override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let dc = segue.destination as?DetailViewController
     dc?.name = name
        dc?.image = image
     dc?.price = String(price)
     dc?.ingredient = ingredient
    }
   
    override func viewDidLoad() {
        super.viewDidLoad()

        fillData()
        welcome.text = "Welcome "+welcomeName + "!!"
        itemView.dataSource = self
        itemView.delegate = self
        // Do any additional setup after loading the view.
    }
    
    
   
func fillData()
{
    itemList.append(Item(name: "Pie", image: "pie",price : 3.47 ,ingredient: "2 eggs , pumpkin puree, sweetened condensed milk,teaspoon pumpkin pie spice,unbaked pie crust"))
    itemList.append(Item(name: "Donut", image: "donut" ,price : 0.99 , ingredient: "flour, baking powder, salt, liquid, and varying amounts of eggs, milk, sugar, shortening and other flavorings. "))
    itemList.append(Item(name: "Muffin", image: "muffin",price : 1.95 , ingredient: "flour, sieved together with bicarbonate of soda as a raising agent. To this is added butter or shortening, eggs and any flavourings (fruit, such as blueberries, chocolate or banana; or savouries, such as cheese)."))
    itemList.append(Item(name: "Coffee", image: "coffee",price : 1.59 , ingredient: "1 cup (240 mL) hot water ,1 to 2 teaspoons instant coffee , 1 to 2 teaspoons sugar (optional),Milk or creamer ,Cocoa, spices, or vanilla extract (optional)"))
    itemList.append(Item(name: "Pastry", image: "pastry",price : 2.20 , ingredient: "flour, sugar, milk, shortening, baking powder and eggs. When these ingredients are combined to form a dough that is flakier or crumblier than bread dough."))
    itemList.append(Item(name: "Cake", image: "cake",price : 8.99, ingredient: "2 eggs,2 teaspoons vanilla extract,1 ½ cups all-purpose flour,1 ¾ teaspoons baking powder,½ cup milk"))
    itemList.append(Item(name: "Ice cream", image: "ice",price :12.99 , ingredient: "Ice cream is a colloidal emulsion made with water, ice, milk fat, milk protein, sugar and air."))
    itemList.append(Item(name: "Chocolava", image: "lava",price : 4.99, ingredient: "Butter, Egg, Sugar, Chocolate,Baking powder"))
}
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
