//
//  DetailViewController.swift
//  Bakery
//
//  Created by Manpreet on 2020-11-23.
//

import UIKit

class DetailViewController: UIViewController {
var name = ""
    var price = ""
    var ingredient = ""
    var image = ""
    var amount = 0.0
    @IBOutlet weak var detailTitle: UITextField!
    
   
    @IBOutlet weak var totalAmount: UITextField!
    @IBOutlet weak var quantity: UITextField!
    @IBOutlet weak var detailIngredient: UITextView!
    @IBOutlet weak var detailPrice: UITextField!
    @IBOutlet weak var detailImage: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()

        detailTitle.text = name
        detailPrice.text = price
        detailIngredient.text = ingredient
        detailImage.image = UIImage(named: image)
        // Do any additional setup after loading the view.
    }
    
    @IBAction func funshare(_ sender: Any) {
        share(sharingText: detailTitle.text, sharingImage: detailImage.image)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    func share(sharingText: String?, sharingImage: UIImage?) {
        let sharingItems:[AnyObject?] = [
                                            sharingText as AnyObject,
                                            sharingImage as AnyObject,
                                           
                                        ]
        let activityViewController = UIActivityViewController(activityItems: sharingItems.compactMap({$0}), applicationActivities: nil)
        if UIDevice.current.userInterfaceIdiom == .pad {
            activityViewController.popoverPresentationController?.sourceView = view
        }
        present(activityViewController, animated: true, completion: nil)
    }

    @IBAction func calculate(_ sender: Any) {
       
        if (quantity.text == "")
        {
            totalAmount.text = ""
        }
        else
        {
            amount = Double(detailPrice.text!)! * Double(quantity.text!)!
            totalAmount.text = String(format:  "%.2f",amount)
        }
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let ovc = segue.destination as?OrderViewController
    }
   
    @IBAction func orderItem(_ sender: Any) {
        
        if (quantity.text == "")
        {
            totalAmount.text = ""
        }
        else
        {
            performSegue(withIdentifier: "order", sender: self)
        }
    }
   
}
