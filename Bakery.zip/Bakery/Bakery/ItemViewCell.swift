//
//  ItemViewCell.swift
//  Bakery
//
//  Created by Manpreet on 2020-11-23.
//

import UIKit

class ItemViewCell: UITableViewCell {

    
    @IBOutlet weak var itemName: UITextField!
    @IBOutlet weak var itemImage: UIImageView!
    
    func setItem(item : Item)
    {
        itemName.text = item.name
        itemImage.image = UIImage(named: item.image)
    }
}
